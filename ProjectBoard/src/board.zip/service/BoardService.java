package board.service;

import java.util.Scanner;


public class BoardService implements Board {

    @Override
    public void execute() {
    	
    }
}

package board.service;

public interface Board {
    public void execute();
}
